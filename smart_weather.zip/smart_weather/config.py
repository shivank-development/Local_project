# config.py
API_KEY = "629fe03d775e8764ce019058e2163db7"  # put your key here
DEFAULT_CITY = "Meerut,IN"

# Polling interval for background checks (minutes)
POLL_INTERVAL_MIN = 15

# Hourly forecast lookahead to trigger "incoming rain" alert (hours)
FORECAST_LOOKAHEAD_HOURS = 2

# AQI thresholds (OpenWeatherMap AQI scale: 1=Good ... 5=Very Poor)
AQI_ALERT_THRESHOLD = 3  # 3 = Unhealthy for sensitive groups and above

# Temperature thresholds (Celsius)
COLD_THRESHOLD = 8
HEAT_THRESHOLD = 33

# Enable voice alerts by default
ENABLE_VOICE_ALERTS = True

# Toggle whether to send notifications on every poll (set to False to reduce spam)
NOTIFY_ON_EVERY_POLL = False
