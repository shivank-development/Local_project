import requests
from config import API_KEY

BASE_WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather"
ONECALL_URL = "https://api.openweathermap.org/data/2.5/onecall"
AQI_URL = "http://api.openweathermap.org/data/2.5/air_pollution"

def get_current_weather(city):
    params = {"q": city, "appid": API_KEY, "units": "metric"}
    try:
        r = requests.get(BASE_WEATHER_URL, params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("get_current_weather error:", e)
        return None

def get_forecast(city):
    """Returns 5-day forecast (3-hour intervals)."""
    params = {"q": city, "appid": API_KEY, "units": "metric"}
    try:
        r = requests.get("http://api.openweathermap.org/data/2.5/forecast", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("get_forecast error:", e)
        return None

def get_aqi(lat, lon):
    params = {"lat": lat, "lon": lon, "appid": API_KEY}
    try:
        r = requests.get(AQI_URL, params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print("get_aqi error:", e)
        return None
