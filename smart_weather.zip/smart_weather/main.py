# main.py
import threading
import time
import os
import sys
import shutil
from tkinter import *
from tkinter import messagebox
from weather_service import get_current_weather, get_forecast, get_aqi
from notification_manager import notify
from voice_alerts import speak
from config import *
import datetime
from sound_player import play_sound

def send_weather_alert(condition):
    if "rain" in condition:
        play_sound("rain.ogg")
    elif "thunderstorm" in condition:
        play_sound("thunder.ogg")
    elif "clear" in condition:
        play_sound("sunny.ogg")
    elif "snow" in condition:
        play_sound("wind.ogg")
    else:
        play_sound("alert.ogg")


class SmartWeatherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Weather Assistant")
        self.root.geometry("420x340")
        self.root.resizable(False, False)

        # UI
        Label(root, text="City (City,CC):").pack(pady=(12,0))
        self.city_entry = Entry(root, font=("Helvetica", 12), width=28)
        self.city_entry.pack(pady=6)
        self.city_entry.insert(0, DEFAULT_CITY)

        self.fetch_btn = Button(root, text="Get Now", command=self.manual_fetch)
        self.fetch_btn.pack(pady=6)

        self.status_label = Label(root, text="Status: Idle", anchor="w", justify=LEFT)
        self.status_label.pack(fill="x", padx=12)

        self.result_text = Text(root, height=10, state="disabled")
        self.result_text.pack(fill="both", padx=12, pady=8)

        # Controls
        self.bg_var = BooleanVar(value=True)
        Checkbutton(root, text="Enable background checker", variable=self.bg_var).pack()
        Button(root, text="Start on boot (Windows)", command=self.install_startup_shortcut).pack(pady=6)

        # Internal state
        self.last_weather_summary = None
        self.is_running = True

        # Start background thread
        self.thread = threading.Thread(target=self.background_loop, daemon=True)
        self.thread.start()

    def install_startup_shortcut(self):
        """
        Create a shortcut in the user's startup folder that runs the executable.
        Works when running as a packaged exe.
        """
        try:
            startup = os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
            exe_path = sys.executable  # when packaged this points to the exe; when running as script, points to python.exe
            if exe_path.lower().endswith(".exe"):
                name = "SmartWeatherAssistant.lnk"
                dest = os.path.join(startup, name)
                # Use winshell or create a .bat as fallback
                try:
                    import pythoncom  # check pywin32 available
                    from win32com.shell import shell, shellcon
                    shortcut = pythoncom.CoCreateInstance(shell.CLSID_ShellLink, None,
                                                          pythoncom.CLSCTX_INPROC_SERVER, shell.IID_IShellLink)
                    shortcut.SetPath(exe_path)
                    shortcut.SetWorkingDirectory(os.path.dirname(exe_path))
                    persist_file = shortcut.QueryInterface(pythoncom.IID_IPersistFile)
                    persist_file.Save(dest, 0)
                    messagebox.showinfo("Startup", "Shortcut added to Startup folder.")
                except Exception:
                    # fallback: create simple .bat
                    bat_path = os.path.join(startup, "Start_SmartWeather.bat")
                    with open(bat_path, "w") as f:
                        f.write(f'@echo off\nstart "" "{exe_path}"\n')
                    messagebox.showinfo("Startup", "Startup .bat placed in Startup folder.")
            else:
                messagebox.showwarning("Startup", "Startup shortcut only works for packaged .exe.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not create startup shortcut: {e}")

    def manual_fetch(self):
        threading.Thread(target=self.fetch_and_process, daemon=True).start()

    def background_loop(self):
        while self.is_running:
            if self.bg_var.get():
                try:
                    self.fetch_and_process(notify_on_every_poll=NOTIFY_ON_EVERY_POLL)
                except Exception as e:
                    print("Background fetch error:", e)
            # Sleep poll interval but break in shorter increments to allow quick exit
            for _ in range(int(POLL_INTERVAL_MIN * 6)):  # check every 10 seconds * steps
                if not self.is_running:
                    break
                time.sleep(10)

    def fetch_and_process(self, notify_on_every_poll=False):
        city = self.city_entry.get().strip()
        if not city:
            return
        self.set_status("Fetching weather...")
        current = get_current_weather(city)
        if not current:
            self.append_result("Failed to fetch current weather.")
            self.set_status("Failed")
            return

        lat = current["coord"]["lat"]
        lon = current["coord"]["lon"]
        temp = current["main"]["temp"]
        desc = current["weather"][0]["description"]
        summary = f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} — {city} — {temp}°C — {desc}"
        speak(f"Weather update for {city}: currently {temp} degrees Celsius with {desc}.")
        # OneCall (hourly)
        onecall = get_forecast(city)
        aqi_data = get_aqi(lat, lon)

        # Compose display
        display = []
        display.append(summary)
        if onecall and "hourly" in onecall:
            next_hours = onecall["hourly"][:FORECAST_LOOKAHEAD_HOURS + 1]
            upcoming = []
            for h in next_hours:
                dt = datetime.datetime.fromtimestamp(h["dt"]).strftime("%H:%M")
                cond = h.get("weather", [{}])[0].get("description", "")
                upcoming.append(f"{dt}: {h['temp']}°C, {cond}")
            display.append("\nNext hours:\n" + "\n".join(upcoming))
            
        if aqi_data and "list" in aqi_data:
            aqi_val = aqi_data["list"][0]["main"]["aqi"]  # 1..5 scale
            display.append(f"\nAir Quality  \n1 = Good...\n5 = Very_Poor \nAir Quality Level: {aqi_val}")
        # Update UI
        self.update_result("\n".join(display)) 
        self.set_status("Updated")

        # Decide whether to notify
        notify_required = False
        notify_msgs = []

        # Weather change detection
        if self.last_weather_summary is None:
            notify_required = True if notify_on_every_poll else False
        else:
            # simple diff: temp change >2C or desc changed significantly
            try:
                old_temp = self.last_weather_summary.get("temp")
                old_desc = self.last_weather_summary.get("desc", "")
                if abs(temp - old_temp) >= 2:
                    notify_required = True
                    notify_msgs.append(f"Temperature changed: {old_temp}°C -> {temp}°C")
                if desc.lower() != old_desc.lower():
                    notify_required = True
                    notify_msgs.append(f"Condition changed: {old_desc} -> {desc}")
            except Exception:
                pass

        # Immediate alerts by thresholds
        if temp <= COLD_THRESHOLD:
            notify_required = True
            notify_msgs.append("Cold alert — bundle up.")
        if temp >= HEAT_THRESHOLD:
            notify_required = True
            notify_msgs.append("Heat alert — stay hydrated.")
        if aqi_data and "list" in aqi_data:
            aqi_val = aqi_data["list"][0]["main"]["aqi"]
            if aqi_val >= AQI_ALERT_THRESHOLD:
                notify_required = True
                notify_msgs.append(f"AQI alert — level {aqi_val}")

        # Hourly forecast rain check
        if onecall and "hourly" in onecall:
            for h in onecall["hourly"][:FORECAST_LOOKAHEAD_HOURS]:
                desc_h = h.get("weather", [{}])[0].get("description", "")
                if "rain" in desc_h.lower() or "storm" in desc_h.lower():
                    notify_required = True
                    notify_msgs.append(f"Rain expected at {datetime.datetime.fromtimestamp(h['dt']).strftime('%H:%M')}: {desc_h}")
                    break

        # If user wants notification each poll and no specific messages, give current condition
        if notify_required or notify_on_every_poll:
            title = f"Weather — {city}"
            message = "; ".join(notify_msgs) if notify_msgs else f"{temp}°C, {desc}"
            # choose weather_type for icon
            if "rain" in desc.lower():
                wtype = "rainy"
            elif "storm" in desc.lower():
                wtype = "stormy"
            elif temp <= COLD_THRESHOLD:
                wtype = "cold"
            else:
                wtype = "sunny"

            notify(title, message, weather_type=wtype)
            if ENABLE_VOICE_ALERTS:
                speak(message)

        # Save last state
        self.last_weather_summary = {"temp": temp, "desc": desc}

    # UI helpers
    def set_status(self, s):
        self.status_label.config(text=f"Status: {s}")

    def append_result(self, text):
        self.result_text.configure(state="normal")
        self.result_text.insert(END, text + "\n")
        self.result_text.configure(state="disabled")

    def update_result(self, text):
        self.result_text.configure(state="normal")
        self.result_text.delete("1.0", END)
        self.result_text.insert(END, text)
        self.result_text.configure(state="disabled")

    def on_close(self):
        self.is_running = False
        self.root.destroy()  

if __name__ == "__main__":
    root = Tk()
    app = SmartWeatherApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
