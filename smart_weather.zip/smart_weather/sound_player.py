import os
import pygame

# Initialize mixer once at the top level
pygame.mixer.init()
SOUND_DIR = os.path.join(os.path.dirname(__file__), "assets", "sounds")

def play_sound(filename):
    file_path = os.path.join(SOUND_DIR, filename)
    try:
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play()
    except Exception as e:
        print(f"Error playing sound: {e}")
