# notification_manager.py
import os
from winotify import Notification, audio

APP_ID = "SmartWeatherAssistant"

ICON_MAP = {
    "sunny": os.path.join("assets", "icons", "sunny.ico"),
    "rainy": os.path.join("assets", "icons", "rainy.ico"),
    "stormy": os.path.join("assets", "icons", "stormy.ico"),
    "cold": os.path.join("assets", "icons", "cold.ico"),
    "default": os.path.join("assets", "icons", "sunny.ico"),
}

def notify(title, message, weather_type="default", loop_sound=False):
    icon = ICON_MAP.get(weather_type, ICON_MAP["default"])
    try:
        toast = Notification(
            app_id=APP_ID,
            title=title,
            msg=message,
            icon=icon
        )
        if loop_sound:
            toast.set_audio(audio.Notification.LoopingAlarm, loop=True)
        else:
            toast.set_audio(audio.Default, loop=False)
        toast.show()
    except Exception as e:
        print("Notification failed:", e)
