from django.shortcuts import render, redirect
from django.db.models import Count, Q
from .models import Game
import random
from django.http import JsonResponse

choices = ["rock", "paper", "scissors"]

def leaderboard_data(request):
    leaderboard_data = (
        Game.objects.values("player_name")
        .annotate(
            wins=Count("id", filter=Q(result="Win")),
            losses=Count("id", filter=Q(result="Lose")),
            draws=Count("id", filter=Q(result="Draw")),
        )
        .order_by("-wins")
    )
    return JsonResponse(list(leaderboard_data), safe=False)


def home(request):
    player_name = request.POST.get("player_name", "").strip()
    result = None
    player_choice = None
    computer_choice = None

    if request.method == "POST" and "choice" in request.POST:
        player_choice = request.POST["choice"]
        computer_choice = random.choice(choices)

        if player_choice == computer_choice:
            result = "Draw"
        elif (player_choice == "rock" and computer_choice == "scissors") or \
             (player_choice == "paper" and computer_choice == "rock") or \
             (player_choice == "scissors" and computer_choice == "paper"):
            result = "Win"
        else:
            result = "Lose"

        Game.objects.create(
            player_name=player_name,
            player_choice=player_choice,
            computer_choice=computer_choice,
            result=result
        )

    elif request.method == "POST" and "clear" in request.POST:
        Game.objects.filter(player_name=player_name).delete()
        return redirect("home")

    games = Game.objects.filter(player_name=player_name).order_by("-created_at") if player_name else None

    return render(request, "home.html", {
        "result": result,
        "player_choice": player_choice,
        "computer_choice": computer_choice,
        "games": games,
        "player_name": player_name
    })


def leaderboard(request):
    leaderboard_data = (
        Game.objects.values("player_name")
        .annotate(
            wins=Count("id", filter=Q(result="Win")),
            losses=Count("id", filter=Q(result="Lose")),
            draws=Count("id", filter=Q(result="Draw")),
        )
        .order_by("-wins")
    )
    return render(request, "leaderboard.html", {"leaderboard": leaderboard_data})
