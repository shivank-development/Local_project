<?php
$path = $_GET['path'] ?? '';
if(!$path){ echo "no path"; exit; }
$path = urldecode($path);
// security: only allow Documents
$doc = getenv('USERPROFILE') . '\\Documents';
if(stripos($path,$doc) !== 0){ echo "Not allowed"; exit; }
shell_exec('start "" "'.$path.'"');
echo "opened";
