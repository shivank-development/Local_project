<?php
// jarvis.php
header('Access-Control-Allow-Origin: *');
$raw = $_GET['query'] ?? '';
$cmd = strtolower(trim($raw));
if($cmd === '') { echo "No command received."; exit; }

// safe logging
file_put_contents("commands/voice.log", date('c')." - ".$cmd.PHP_EOL, FILE_APPEND);

$reply = "Sorry, I didn't understand.";

function run_cmd($c){ // wrapper so we can debug
    // For windows we use shell_exec; ensure PHP runs with privileges
    $out = shell_exec($c . " 2>&1");
    return $out;
}

/* -----------------------
   Quick command map
   ----------------------- */
if(strpos($cmd, 'open youtube') !== false || strpos($cmd, 'youtube') !== false){
    // open youtube in default browser (windows)
    run_cmd('start "" "https://youtube.com"');
    $reply = "Opening YouTube.";
}

if(strpos($cmd, 'open google') !== false || strpos($cmd, 'google') !== false){
    run_cmd('start "" "https://google.com"');
    $reply = "Opening Google.";
}

/* --------- WhatsApp support (opens web) ---------- */
if(preg_match('/whatsapp (send|message|msg)/', $cmd) || strpos($cmd,'send whatsapp')!==false){
    // format: "send whatsapp hello to +911234567890" or "whatsapp send hello to 91234567890"
    // naive parse phone & message
    preg_match('/to\s+(\+?\d{8,15})/',$cmd,$m);
    $phone = $m[1] ?? '';
    // message = everything after 'whatsapp' or 'send' up to 'to'
    $message = preg_replace('/.*whatsapp\s*(send|message|msg)?\s*/','',$cmd);
    $message = preg_replace('/\s*to\s*\+?\d{8,15}.*/','',$message);
    $url = 'https://web.whatsapp.com/send?phone='.urlencode($phone).'&text='.urlencode($message);
    run_cmd('start "" "'.$url.'"');
    $reply = $phone ? "Opening WhatsApp chat for $phone" : "Opening WhatsApp web.";
}

/* --------- WhatsApp via API (stub) ----------
   If you want server-side WhatsApp via Twilio, use whatsapp.php and provide credentials.
   I include the stub file in the project. */

/* ---------- File search (dashboard uses this) ---------- */
if(strpos($cmd,'find file')!==false || strpos($cmd,'find')!==false){
    // find <query>
    preg_match('/find (?:file )?(.*)/',$cmd,$m);
    $q = $m[1] ?? '';
    $q = trim($q);
    if($q === '') { $reply = "Please specify file name."; echo $reply; exit; }
    // Use Windows 'where' or 'dir'. This may take time — keep simple:
    // Search only under user's Documents to be safer
    $docPath = getenv('USERPROFILE') . '\\Documents';
    $escaped = str_replace('"','\"',$q);
    $res = run_cmd("powershell -Command \"Get-ChildItem -Path '$docPath' -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { \$_.Name -like '*$escaped*' } | Select-Object -First 50 | ForEach-Object { \$_.FullName }\"");
    if(trim($res)==='') $reply = "No files found for \"$q\" in Documents.";
    else $reply = trim($res);
    echo $reply; exit;
}

/* --------- System: Battery --------- */
if(strpos($cmd,'battery') !== false){
    $bat = run_cmd('WMIC Path Win32_Battery Get EstimatedChargeRemaining');
    $bat = preg_replace('/[^0-9]/','',$bat);
    $reply = $bat ? "Battery: $bat%" : "Battery info not available.";
}

/* --------- System: Volume (requires nircmd or powershell) --------- */
if(strpos($cmd,'volume') !== false){
    if(strpos($cmd,'mute') !== false){
        // using nircmd example:
        run_cmd('nircmd.exe mutesysvolume 1');
        $reply = "Volume muted.";
    } elseif(preg_match('/volume\s*(\d{1,3})/',$cmd,$m)){
        $val = intval($m[1]);
        // nircmd volume range 0..65535
        $v = intval($val/100 * 65535);
        run_cmd("nircmd.exe setsysvolume $v");
        $reply = "Volume set to $val percent.";
    } elseif(strpos($cmd,'max') !== false || strpos($cmd,'full') !== false){
        run_cmd('nircmd.exe setsysvolume 65535');
        $reply = "Volume set to maximum.";
    } else {
        $reply = "Volume command executed.";
    }
}

/* --------- Brightness (PowerShell) --------- */
if(strpos($cmd,'brightness') !== false){
    if(preg_match('/(\d{1,3})/', $cmd, $m)){
        $p = intval($m[1]);
        if($p < 0) $p = 0;
        if($p > 100) $p = 100;
        $ps = "powershell -Command \"(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,$p)\"";
        run_cmd($ps);
        $reply = "Brightness set to $p percent.";
    } else $reply = "Please specify brightness percent (0-100).";
}

/* --------- Wi-Fi (Windows netsh) --------- */
if(strpos($cmd,'wifi') !== false || strpos($cmd,'wi-fi') !== false){
    if(strpos($cmd,'on') !== false){
        run_cmd('netsh interface set interface name="Wi-Fi" admin=ENABLED');
        $reply = "Wi-Fi turned on.";
    } elseif(strpos($cmd,'off') !== false){
        run_cmd('netsh interface set interface name="Wi-Fi" admin=DISABLED');
        $reply = "Wi-Fi turned off.";
    } else $reply = "Wi-Fi command executed.";
}

/* --------- Bluetooth --------- */
if(strpos($cmd,'bluetooth') !== false){
    if(strpos($cmd,'on') !== false){
        run_cmd('powershell Start-Service bthserv');
        $reply = "Bluetooth turned on.";
    } elseif(strpos($cmd,'off') !== false){
        run_cmd('powershell Stop-Service bthserv');
        $reply = "Bluetooth turned off.";
    } else $reply = "Bluetooth command executed.";
}

/* --------- Camera (open cam page) --------- */
if(strpos($cmd,'camera') !== false){
    run_cmd('start "" "cam.html"');
    $reply = "Camera UI opened.";
}

/* --------- Location (browser-based) ---------- */
if(strpos($cmd,'location') !== false || strpos($cmd,'where am i')!==false){
    // location is done client-side; include a hint
    $reply = "Please allow location in your browser; opening dashboard with location.";
    // open dashboard where client can query navigator.geolocation
    run_cmd('start "" "dashboard.html"');
}

/* --------- Notes ---------- */
if(strpos($cmd,'note') !== false){
    file_put_contents("commands/notes.txt", date('c')." - ".$raw.PHP_EOL, FILE_APPEND);
    $reply = "Saved note.";
}

/* --------- AI generation stub (calls OpenAI if configured) ---------- */
if(strpos($cmd,'generate') !== false || strpos($cmd,'write') !== false || strpos($cmd,'compose')!==false){
    // simple echo fallback
    $reply = "AI generation not configured on server. Use local fallback: " . substr($cmd,0,120);
    // If you add API keys, call OpenAI Chat completions here.
}

echo $reply;
